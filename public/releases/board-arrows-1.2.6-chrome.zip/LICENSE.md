Board Arrows links against Stockfish and is distributed under GPL-3.0.

The Stockfish license is `vendor/stockfish/Copying.txt`.
Stockfish.js is GPL-3.0: https://github.com/nmrugg/stockfish.js

chess.js is BSD licensed. Its notice stays in `vendor/chess/chess-global.js`.
