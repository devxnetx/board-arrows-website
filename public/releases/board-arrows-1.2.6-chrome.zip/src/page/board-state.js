(function () {
  var KEYS = ["game", "controller", "state", "chess", "position", "model", "chessboard"];
  var METHODS = ["getFEN", "getFen", "toFen", "getPosition"];

  function looksLikeFen(value) {
    if (typeof value !== "string") return "";
    value = value.trim();
    if (!value) return "";
    var placement = value.split(/\s+/)[0];
    if (placement.split("/").length !== 8) return "";
    if (!/^[prnbqkPRNBQK1-8/]+$/.test(placement)) return "";
    return value;
  }

  function callFen(obj) {
    if (!obj || (typeof obj !== "object" && typeof obj !== "function")) return "";
    var i;
    for (i = 0; i < METHODS.length; i++) {
      try {
        var fn = obj[METHODS[i]];
        if (typeof fn !== "function") continue;
        var value = looksLikeFen(fn.call(obj));
        if (value) return value;
      } catch (err) { /* page method is not readable */ }
    }
    try {
      if (typeof obj.getFens === "function") {
        var list = obj.getFens();
        if (list && list.length) {
          var last = looksLikeFen(list[list.length - 1]);
          if (last) return last;
        }
      }
    } catch (err) { /* history is not readable */ }
    try {
      if (typeof obj.fen === "string") {
        var direct = looksLikeFen(obj.fen);
        if (direct) return direct;
      }
    } catch (err) { /* fen field is not readable */ }
    return "";
  }

  function walk(obj, depth, seen) {
    if (!obj || typeof obj !== "object" || depth > 3 || seen.has(obj)) return "";
    seen.add(obj);
    var found = callFen(obj);
    if (found) return found;
    if (depth === 3) return "";
    for (var i = 0; i < KEYS.length; i++) {
      var child = null;
      try { child = obj[KEYS[i]]; } catch (err) { child = null; }
      found = walk(child, depth + 1, seen);
      if (found) return found;
    }
    return "";
  }

  function boardEl() {
    var nodes = [];
    try { nodes = document.querySelectorAll("wc-chess-board, chess-board"); } catch (err) { return null; }
    var best = null;
    var bestSize = 0;
    for (var i = 0; i < nodes.length; i++) {
      var size = nodes[i].offsetWidth || 0;
      if (size >= bestSize) {
        best = nodes[i];
        bestSize = size;
      }
    }
    return best;
  }

  function gameFlipped(el) {
    var game = null;
    try { game = el.game || (el.controller && el.controller.game) || null; } catch (err) { game = null; }
    if (!game) return "";
    try {
      if (typeof game.getOptions === "function") {
        var options = game.getOptions();
        if (options && options.flipped === true) return "1";
        if (options && options.flipped === false) return "0";
      }
    } catch (err) { /* options are not readable */ }
    try {
      if (game.flipped === true) return "1";
    } catch (err) { /* game flip is not readable */ }
    return "";
  }

  function flippedOf(el) {
    if (!el) return "";
    try {
      if (el.classList && (el.classList.contains("flipped") || el.classList.contains("orientation-black"))) return "1";
    } catch (err) { /* class list is not readable */ }
    try {
      if (el.hasAttribute && el.hasAttribute("flipped")) {
        var flag = el.getAttribute("flipped");
        if (flag === "" || flag === "true") return "1";
        if (flag === "false") return "0";
      }
    } catch (err) { /* flipped attribute is not readable */ }
    var orientation = "";
    try { orientation = String(el.getAttribute("orientation") || el.orientation || "").toLowerCase(); } catch (err) { orientation = ""; }
    if (orientation === "black") return "1";
    if (orientation === "white") return "0";
    // The canvas board draws the 8 itself and does not add a flipped class.
    // The game options are what the site uses when it turns the board.
    var fromGame = gameFlipped(el);
    if (fromGame) return fromGame;
    try {
      if (el.flipped === true) return "1";
      if (el.flipped === false) return "0";
    } catch (err) { /* flipped field is not readable */ }
    var child = null;
    try { child = el.game || el.controller || null; } catch (err) { child = null; }
    if (!child) return "";
    try {
      var nested = typeof child.getOrientation === "function" ? child.getOrientation() : child.orientation;
      nested = String(nested || "").toLowerCase();
      if (nested === "black" || child.flipped === true) return "1";
      if (nested === "white") return "0";
    } catch (err) { /* orientation is not readable */ }
    return "";
  }

  function publish() {
    var root = document.documentElement;
    if (!root) return;
    var board = null;
    try { board = boardEl(); } catch (err) { board = null; }
    if (!board) {
      if (root.hasAttribute("data-ba-fen")) root.removeAttribute("data-ba-fen");
      if (root.hasAttribute("data-ba-flip")) root.removeAttribute("data-ba-flip");
      return;
    }
    var fen = "";
    try {
      var game = board.game || (board.controller && board.controller.game) || null;
      if (game && typeof game.getFEN === "function") fen = looksLikeFen(game.getFEN());
      if (!fen && game && typeof game.getFen === "function") fen = looksLikeFen(game.getFen());
    } catch (err) { fen = ""; }
    if (!fen) {
      try { fen = walk(board, 0, new Set()); } catch (err) { fen = ""; }
    }
    if (fen && root.getAttribute("data-ba-fen") !== fen) root.setAttribute("data-ba-fen", fen);
    var flip = "";
    try { flip = flippedOf(board); } catch (err) { flip = ""; }
    if (flip && root.getAttribute("data-ba-flip") !== flip) root.setAttribute("data-ba-flip", flip);
  }

  setInterval(publish, 200);
  publish();
})();
