(function () {
  var api = globalThis.chrome || globalThis.browser;

  function extensionVersion() {
    try { return api.runtime.getManifest().version || "1.2.6"; } catch (err) { return "1.2.6"; }
  }
  var settings = self.BASettings.normalize(null);
  var host = null;
  var shadow = null;
  var svg = null;
  var panel = null;
  var depthEl = null;
  var scoreEl = null;
  var barEl = null;
  var linesEl = null;
  var noteEl = null;
  var fenEl = null;
  var bodyEl = null;
  var boardEl = null;
  var observer = null;
  var port = null;
  var token = 0;
  var lastFen = "";
  var pendingView = null;
  var readTimer = 0;
  var placeQueued = false;
  var localEngine = null;
  var usePort = false;
  var lastJob = null;
  var waitTimer = 0;

  var CRITICAL_CSS = ""
    + ":host{all:initial;}"
    + ".ba-svg{position:fixed;z-index:2147483646;pointer-events:none;overflow:visible;}"
    + ".ba-panel{position:fixed;top:72px;right:16px;z-index:2147483647;width:280px;box-sizing:border-box;padding:10px 12px 8px;border-radius:10px;background:rgba(20,24,18,.94);color:#f3f0e6;font:13px/1.35 Segoe UI,sans-serif;box-shadow:0 10px 28px rgba(0,0,0,.35);}"
    + ".ba-head{display:flex;align-items:center;gap:8px;cursor:grab;}"
    + ".ba-depth{margin-left:auto;color:#b7c3ad;}"
    + ".ba-icon{width:22px;height:22px;border:0;border-radius:6px;background:transparent;color:#f3f0e6;cursor:pointer;}"
    + ".ba-score-row{display:flex;align-items:center;gap:8px;margin-top:8px;}"
    + ".ba-bar{position:relative;flex:1;height:10px;border-radius:99px;background:#2a2a2a;overflow:hidden;}"
    + ".ba-bar i{display:block;height:100%;width:50%;background:#f4f1e8;}"
    + ".ba-lines{margin:8px 0 0;padding:0;list-style:none;}"
    + ".ba-note{margin-top:8px;color:#f0d48a;}"
    + ".ba-fen{margin-top:6px;color:#9aa58e;font-size:11px;word-break:break-all;}"
    + ".ba-panel.is-hidden .ba-body{display:none;}";

  function boot() {
    host = document.createElement("div");
    host.id = "board-arrows-host";
    host.style.cssText = "position:fixed;left:0;top:0;width:0;height:0;overflow:visible;z-index:2147483646;pointer-events:none;";
    shadow = host.attachShadow({ mode: "open" });
    document.documentElement.appendChild(host);

    var style = document.createElement("style");
    style.textContent = CRITICAL_CSS;
    shadow.appendChild(style);
    fetch(api.runtime.getURL("src/content/overlay.css"))
      .then(function (res) { return res.text(); })
      .then(function (css) {
        if (css && css.indexOf(".ba-svg") !== -1) style.textContent = css;
      })
      .catch(function () { /* critical CSS already applied */ });

    svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("class", "ba-svg");
    svg.setAttribute("viewBox", "0 0 100 100");
    svg.setAttribute("preserveAspectRatio", "none");
    svg.style.position = "fixed";
    svg.style.zIndex = "2147483646";
    svg.style.pointerEvents = "none";
    svg.style.display = "none";
    shadow.appendChild(svg);

    panel = document.createElement("div");
    panel.className = "ba-panel";
    panel.style.pointerEvents = "auto";
    panel.innerHTML =
      '<div class="ba-head"><strong class="ba-title">Board Arrows ' + extensionVersion() + '</strong><span class="ba-depth"></span><button class="ba-icon" type="button" title="Hide lines">–</button></div>' +
      '<div class="ba-body"><div class="ba-score-row"><div class="ba-bar"><i></i></div><div class="ba-score">…</div></div><ol class="ba-lines"></ol><div class="ba-note"></div><div class="ba-fen"></div></div>';
    panel.hidden = true;
    shadow.appendChild(panel);
    depthEl = panel.querySelector(".ba-depth");
    scoreEl = panel.querySelector(".ba-score");
    barEl = panel.querySelector(".ba-bar i");
    linesEl = panel.querySelector(".ba-lines");
    noteEl = panel.querySelector(".ba-note");
    fenEl = panel.querySelector(".ba-fen");
    bodyEl = panel.querySelector(".ba-body");
    panel.querySelector(".ba-icon").addEventListener("click", function () {
      panel.classList.toggle("is-hidden");
    });
    drag(panel.querySelector(".ba-head"), panel);

    connect();
    api.storage.local.get("boardArrows", function (data) {
      settings = self.BASettings.normalize(data && data.boardArrows);
      scheduleRead();
    });
    api.storage.onChanged.addListener(function (changes, area) {
      if (area !== "local" || !changes.boardArrows) return;
      settings = self.BASettings.normalize(changes.boardArrows.newValue);
      lastFen = "";
      scheduleRead();
    });

    window.addEventListener("resize", queuePlace);
    window.addEventListener("scroll", queuePlace, true);
    window.addEventListener("keydown", onKey, true);
    document.addEventListener("visibilitychange", function () {
      if (document.hidden) send({ type: "stop", token: ++token });
      else scheduleRead();
    });
    if (document.documentElement) {
      new MutationObserver(scheduleRead).observe(document.documentElement, {
        attributes: true,
        attributeFilter: ["data-ba-fen", "data-ba-flip"],
      });
    }
    setInterval(pollBoard, 700);
    pollBoard();
  }

  function connect() {
    try {
      port = api.runtime.connect({ name: "board-arrows" });
    } catch (err) {
      port = null;
      return;
    }
    port.onMessage.addListener(onAnalysis);
    port.onDisconnect.addListener(function () { port = null; });
  }

  function ensureEngine() {
    if (localEngine || usePort) return;
    try {
      localEngine = self.BAEngine.create(onAnalysis, function () {
        usePort = true;
        if (lastJob) sendViaPort(lastJob);
      });
    } catch (err) {
      usePort = true;
      localEngine = null;
    }
  }

  function sendViaPort(msg) {
    if (!port) connect();
    if (!port) return;
    try {
      port.postMessage(msg);
    } catch (err) {
      port = null;
    }
  }

  api.runtime.onMessage.addListener(function (msg) {
    if (msg && msg.type === "analysis") onAnalysis(msg);
  });

  function send(msg) {
    if (msg && msg.type === "analyze") lastJob = msg;
    ensureEngine();
    if (!usePort && localEngine && localEngine.handle(msg)) return;
    usePort = true;
    sendViaPort(msg);
  }

  function drag(handle, box) {
    handle.addEventListener("mousedown", function (ev) {
      if (ev.button !== 0 || ev.target.closest("button")) return;
      var originX = ev.clientX;
      var originY = ev.clientY;
      var rect = box.getBoundingClientRect();
      function move(e) {
        box.style.left = rect.left + (e.clientX - originX) + "px";
        box.style.top = rect.top + (e.clientY - originY) + "px";
        box.style.right = "auto";
      }
      function up() {
        window.removeEventListener("mousemove", move);
        window.removeEventListener("mouseup", up);
      }
      window.addEventListener("mousemove", move);
      window.addEventListener("mouseup", up);
      ev.preventDefault();
    });
  }

  function onKey(ev) {
    if (!ev.altKey || ev.repeat || String(ev.key).toLowerCase() !== "a") return;
    var tag = ev.target && ev.target.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
    settings.enabled = !settings.enabled;
    api.storage.local.set({ boardArrows: settings });
    ev.preventDefault();
  }

  function pollBoard() {
    var found = self.BAFen.findBoard(document);
    var next = found && found.board;
    if (next !== boardEl) {
      boardEl = next;
      if (observer) observer.disconnect();
      observer = null;
      if (boardEl) {
        observer = new MutationObserver(scheduleRead);
        var root = boardEl.shadowRoot || boardEl;
        observer.observe(root, {
          subtree: true,
          childList: true,
          attributes: true,
          attributeFilter: ["class", "style", "flipped"],
        });
        if (boardEl.parentElement) {
          observer.observe(boardEl.parentElement, {
            attributes: true,
            attributeFilter: ["class", "flipped"],
          });
        }
      }
      lastFen = "";
    }
    if (host && host.parentNode && host.parentNode.lastElementChild !== host) {
      host.parentNode.appendChild(host);
    }
    scheduleRead();
  }

  function scheduleRead() {
    clearTimeout(readTimer);
    readTimer = setTimeout(readNow, 90);
  }

  function readNow() {
    if (!settings.enabled) {
      if (lastFen !== "") {
        lastFen = "";
        hideAll();
        send({ type: "stop", token: ++token });
      } else {
        hideAll();
      }
      return;
    }
    var position = null;
    try {
      position = self.BAFen.readPosition(document);
    } catch (err) {
      position = null;
    }
    if (!position) {
      if (boardEl) {
        panel.hidden = !settings.showPanel;
        clearArrows();
        svg.style.display = "none";
        depthEl.textContent = "";
        scoreEl.textContent = "";
        linesEl.textContent = "";
        fenEl.textContent = "";
        var issue = self.BAFen.lastIssue ? " " + self.BAFen.lastIssue + "." : ".";
        noteEl.textContent = "A board is on the page, but its pieces could not be read." + issue;
      } else {
        hideAll();
      }
      if (lastFen) {
        lastFen = "";
        send({ type: "stop", token: ++token });
      }
      return;
    }

    panel.hidden = !settings.showPanel;
    queuePlace();
    var live = settings.pauseOnLive && self.BALive.isLiveHuman(location.href, self.BALive.detectBot(document, position.site));
    if (live) {
      if (lastFen !== "live:" + position.fen) {
        lastFen = "live:" + position.fen;
        clearArrows();
        depthEl.textContent = "";
        scoreEl.textContent = "";
        barEl.style.width = "50%";
        linesEl.textContent = "";
        send({ type: "stop", token: ++token });
      }
      fenEl.textContent = position.fen;
      noteEl.textContent = "Paused on a live game. Uncheck Pause on live games in the Board Arrows toolbar button.";
      return;
    }

    noteEl.textContent = "";
    if (position.fen === lastFen) {
      paint();
      queuePlace();
      return;
    }
    pendingView = null;
    lastFen = position.fen;
    fenEl.textContent = position.fen;
    scoreEl.textContent = "…";
    var job = ++token;
    clearTimeout(waitTimer);
    waitTimer = setTimeout(function () {
      if (job !== token || pendingView) return;
      noteEl.textContent = "Stockfish has not answered yet. In about:debugging, click Reload on Board Arrows, then refresh this tab.";
      panel.hidden = false;
    }, 8000);
    send({
      type: "analyze",
      fen: position.fen,
      depth: settings.depth,
      multiPv: settings.multiPv,
      token: job,
    });
  }

  function onAnalysis(msg) {
    if (!msg || msg.token !== token) return;
    if (msg.error) {
      noteEl.textContent = msg.error;
      panel.hidden = false;
      return;
    }
    clearTimeout(waitTimer);
    noteEl.textContent = "";
    pendingView = msg;
    paint();
  }

  function paint() {
    if (!pendingView || pendingView.token !== token) return;
    var position = null;
    try {
      position = self.BAFen.readPosition(document);
    } catch (err) {
      position = null;
    }
    if (!position || position.fen !== lastFen) return;
    render(position, pendingView);
  }

  function render(position, msg) {
    depthEl.textContent = msg.depth ? "depth " + msg.depth : "";
    var best = msg.lines && msg.lines[0];
    scoreEl.textContent = self.BAUci.formatEval(best);
    barEl.style.width = self.BAUci.whiteShare(best).toFixed(1) + "%";

    linesEl.textContent = "";
    (msg.lines || []).forEach(function (line, index) {
      var sans = self.BASan.lineToSan(position.fen, line.pv || []);
      var item = document.createElement("li");
      var swatch = document.createElement("span");
      swatch.className = "ba-swatch";
      swatch.style.background = self.BAArrows.COLORS[index % self.BAArrows.COLORS.length];
      var san = document.createElement("span");
      san.className = "ba-san";
      san.textContent = sans[0] || (line.pv && line.pv[0]) || "";
      if (sans.length > 1) {
        var rest = document.createElement("span");
        rest.className = "ba-rest";
        rest.textContent = self.BASan.formatLine(sans, position.turn);
        san.appendChild(rest);
      }
      var cp = document.createElement("span");
      cp.className = "ba-cp";
      cp.textContent = self.BAUci.formatEval(line);
      item.appendChild(swatch);
      item.appendChild(san);
      item.appendChild(cp);
      linesEl.appendChild(item);
    });

    var bottom = position.flipped ? "b" : "w";
    var arrows = self.BAArrows.arrowsFor(msg.lines || [], settings);
    if (settings.onlyBottomTurn && position.turn !== bottom) arrows = [];
    self.BAArrows.draw(svg, arrows, position.flipped, settings);
    queuePlace();
  }

  function clearArrows() {
    while (svg.firstChild) svg.removeChild(svg.firstChild);
  }

  function hideAll() {
    panel.hidden = true;
    svg.style.display = "none";
    clearArrows();
  }

  function queuePlace() {
    if (placeQueued) return;
    placeQueued = true;
    requestAnimationFrame(function () {
      placeQueued = false;
      if (!boardEl || !settings.enabled) {
        svg.style.display = "none";
        return;
      }
      var rect = boardEl.getBoundingClientRect();
      if (rect.width < 80 || rect.height < 80) {
        svg.style.display = "none";
        return;
      }
      svg.style.display = "block";
      svg.style.position = "fixed";
      svg.style.zIndex = "2147483646";
      svg.style.pointerEvents = "none";
      svg.style.left = rect.left + "px";
      svg.style.top = rect.top + "px";
      svg.style.width = rect.width + "px";
      svg.style.height = rect.height + "px";
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  } else {
    boot();
  }
})();
