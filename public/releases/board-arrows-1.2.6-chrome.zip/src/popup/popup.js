var api = globalThis.chrome || globalThis.browser;
var fields = ["enabled", "showPanel", "onlyBottomTurn", "continuationsOnAllLines", "showNumbers", "pauseOnLive"];
var ranges = ["depth", "multiPv", "continuationPlies"];

function migrate(raw) {
  raw = raw || {};
  if (raw.pauseOnLiveSet !== true) {
    raw = Object.assign({}, raw, { pauseOnLive: false });
  }
  return raw;
}

function apply(settings) {
  fields.forEach(function (id) {
    document.getElementById(id).checked = !!settings[id];
  });
  ranges.forEach(function (id) {
    document.getElementById(id).value = String(settings[id]);
  });
  document.getElementById("depthOut").textContent = settings.depth;
  document.getElementById("multiOut").textContent = settings.multiPv;
  document.getElementById("contOut").textContent = settings.continuationPlies;
}

function collect() {
  var raw = {};
  fields.forEach(function (id) {
    raw[id] = document.getElementById(id).checked;
  });
  ranges.forEach(function (id) {
    raw[id] = Number(document.getElementById(id).value);
  });
  raw.pauseOnLiveSet = true;
  return raw;
}

function save() {
  var settings = collect();
  apply(settings);
  api.storage.local.set({ boardArrows: settings });
}

try {
  var manifest = api.runtime.getManifest();
  document.getElementById("addonName").textContent = manifest.name;
} catch (err) { /* popup is not running inside the add-on */ }

api.storage.local.get("boardArrows", function (data) {
  var settings = migrate(data && data.boardArrows);
  if (!data || !data.boardArrows) {
    settings = {
      enabled: true,
      showPanel: true,
      onlyBottomTurn: false,
      continuationsOnAllLines: false,
      showNumbers: false,
      pauseOnLive: false,
      depth: 14,
      multiPv: 3,
      continuationPlies: 3,
    };
  }
  apply(settings);
});

document.body.addEventListener("change", save);
document.body.addEventListener("input", function (ev) {
  if (ev.target && ev.target.type === "range") save();
});
