(function () {
  var api = globalThis.chrome || globalThis.browser;
  var ports = new Set();
  var activePort = null;
  var worker = null;
  var ready = false;
  var searching = false;
  var pending = null;
  var active = null;
  var lines = new Map();
  var depthSeen = 0;
  var publishTimer = null;

  function boot() {
    var url = api.runtime.getURL("vendor/stockfish/stockfish-19-lite-single.js");
    worker = new Worker(url);
    worker.onmessage = onEngine;
    worker.onerror = function (err) {
      publish({
        type: "analysis",
        error: "Stockfish failed to start.",
        detail: String((err && err.message) || err),
        token: active && active.token,
        tabId: active && active.tabId,
      }, true);
    };
    worker.postMessage("uci");
    worker.postMessage("isready");
  }

  function ensureBoot() {
    if (worker) return;
    boot();
  }

  function onEngine(event) {
    var line = typeof event.data === "string" ? event.data : "";
    if (!line) return;
    if (line === "readyok") {
      if (!ready) {
        ready = true;
        worker.postMessage("setoption name Hash value 16");
        try {
          var sent = api.runtime.sendMessage({ type: "engine-ready" });
          if (sent && typeof sent.catch === "function") sent.catch(function () {});
        } catch (err) { /* no listener yet */ }
      }
      if (pending && !searching) start();
      return;
    }
    if (line.indexOf("bestmove") === 0) {
      searching = false;
      publish(collect(true), true);
      active = null;
      if (pending) start();
      return;
    }
    var info = self.BAUci.parseInfo(line);
    if (!info || !active) return;
    if (info.multipv > (active.multiPv || 1)) return;
    if (info.depth < depthSeen) return;
    if (info.depth > depthSeen) {
      depthSeen = info.depth;
      lines = new Map();
    }
    lines.set(info.multipv, info);
    schedule();
  }

  function start() {
    if (!ready || searching || !pending) return;
    active = pending;
    pending = null;
    lines = new Map();
    depthSeen = 0;
    searching = true;
    worker.postMessage("setoption name MultiPV value " + String(active.multiPv || 1));
    worker.postMessage("position fen " + active.fen);
    worker.postMessage("go depth " + String(active.depth || 14));
  }

  function request(msg, port) {
    ensureBoot();
    if (port) activePort = port;
    if (msg.type === "stop") {
      pending = null;
      if (searching) worker.postMessage("stop");
      return;
    }
    if (msg.type !== "analyze" || !msg.fen) return;
    pending = {
      fen: msg.fen,
      depth: msg.depth || 14,
      multiPv: msg.multiPv || 1,
      token: msg.token,
      tabId: msg.tabId,
    };
    if (!ready) return;
    if (searching) {
      worker.postMessage("stop");
      return;
    }
    start();
  }

  function collect(final) {
    if (!active) return null;
    var turn = active.fen.split(" ")[1] || "w";
    var packed = Array.from(lines.values())
      .sort(function (a, b) { return a.multipv - b.multipv; })
      .map(function (info) {
        var score = self.BAUci.toWhite(info, turn);
        return {
          multipv: info.multipv,
          depth: info.depth,
          cp: score.cp,
          mate: score.mate,
          pv: info.pv,
        };
      });
    return {
      type: "analysis",
      token: active.token,
      tabId: active.tabId,
      depth: depthSeen,
      final: !!final,
      lines: packed,
    };
  }

  function schedule() {
    if (publishTimer) return;
    publishTimer = setTimeout(function () {
      publishTimer = null;
      var payload = collect(false);
      if (payload) publish(payload, false);
    }, 120);
  }

  function publish(payload, immediate) {
    if (!payload) return;
    if (immediate && publishTimer) {
      clearTimeout(publishTimer);
      publishTimer = null;
    }
    if (activePort) {
      try {
        activePort.postMessage(payload);
        return;
      } catch (err) {
        activePort = null;
      }
    }
    ports.forEach(function (port) {
      try { port.postMessage(payload); } catch (err) { ports.delete(port); }
    });
    if (payload.tabId && api.tabs) {
      try {
        var posted = api.tabs.sendMessage(payload.tabId, payload);
        if (posted && typeof posted.catch === "function") posted.catch(function () {});
      } catch (err) { /* tab closed */ }
    }
  }

  api.runtime.onConnect.addListener(function (port) {
    if (!port || port.name !== "board-arrows") return;
    ports.add(port);
    port.onMessage.addListener(function (msg) { request(msg, port); });
    port.onDisconnect.addListener(function () {
      ports.delete(port);
      if (activePort === port) activePort = null;
    });
  });

  api.runtime.onMessage.addListener(function (msg) {
    if (!msg || msg.target !== "engine") return;
    request(msg, null);
  });

  var pageUrl = String((globalThis.location && globalThis.location.href) || "");
  if (pageUrl.indexOf("engine.html") !== -1) boot();
})();
