var readyWait = [];
var engineUp = false;

function markReady() {
  engineUp = true;
  var waiting = readyWait;
  readyWait = [];
  waiting.forEach(function (resolve) { resolve(); });
}

chrome.runtime.onMessage.addListener(function (msg) {
  if (msg && msg.type === "engine-ready") markReady();
});

function engineReady() {
  if (engineUp) return Promise.resolve();
  return new Promise(function (resolve) {
    readyWait.push(resolve);
    setTimeout(resolve, 8000);
  });
}

async function ensureEngine() {
  var exists = false;
  try {
    exists = await chrome.offscreen.hasDocument();
  } catch (err) {
    exists = false;
  }
  if (exists) return;
  await chrome.offscreen.createDocument({
    url: "src/engine.html",
    reasons: ["WORKERS"],
    justification: "Run the local Stockfish engine while a chess board is open.",
  });
  await engineReady();
}

chrome.runtime.onConnect.addListener(function (port) {
  if (!port || port.name !== "board-arrows") return;
  var tabId = port.sender && port.sender.tab && port.sender.tab.id;
  port.onMessage.addListener(function (msg) {
    ensureEngine()
      .then(function () {
        chrome.runtime.sendMessage(Object.assign({}, msg, { target: "engine", tabId: tabId }));
      })
      .catch(function (err) {
        port.postMessage({ type: "analysis", error: "Could not start Stockfish.", detail: String(err), token: msg && msg.token });
      });
  });
});
