# Board Arrows

A Firefox and Chrome extension that draws Stockfish arrows on Chess.com and Lichess.

The thick arrow is the move to play. Thin numbered arrows are the next moves in that line: 2, 4, 6 are the other side, and 3, 5, 7 are the replies after that. Other colors are the next-best first moves. The engine is Stockfish 19 Lite and it runs on your machine. Nothing is sent out for analysis.

This is an original extension. Chess Helper (chesshelper.app) is closed source, so this does not contain its code. The arrow idea is the same: show the best move, then the moves that follow it.

## Install on Firefox

1. Open `about:debugging`.
2. Choose **This Firefox**.
3. Click **Load Temporary Add-on**.
4. Select `manifest.json` in this folder.

Temporary add-ons go away when Firefox closes. Load it again after a restart. After this folder changes, click **Reload** on Board Arrows in `about:debugging`, then refresh the chess tab. The add-on name in that list should say Board Arrows 1.2.6.

## Install on Chrome or Edge

1. Copy `manifest.chrome.json` over `manifest.json`.
2. Open `chrome://extensions`.
3. Turn on **Developer mode**.
4. Click **Load unpacked** and select this folder.

## Use it

Open an analysis board, a puzzle, or a game. Arrows appear after Stockfish reaches the first depths, then update until the depth in the popup. A dark panel in the top-right lists the same line.

The popup sets:

- depth, from 6 to 22
- how many candidate arrows to draw, from 1 to 5
- how many following moves to number on the best line
- whether every line gets those following arrows
- arrows only when the bottom side is to move
- pause on live games

Alt+A hides the arrows. Drag the panel by its title.

Arrows stay on during live games unless **Pause on live games** is checked. Chess.com and Lichess both ban engine help in games against people, and accounts get closed for it.

## Limits

Castling rights are guessed from where the king and rooks stand. En passant is guessed from the highlighted last move. If a site changes its board markup, the panel's FEN line is the position the extension actually read.

## Credits

Stockfish is GPL-3.0. The WebAssembly build is [Stockfish.js](https://github.com/nmrugg/stockfish.js) 19.0.1. See `vendor/stockfish/Copying.txt`.

chess.js 0.13.4 by Jeff Hlywa is BSD licensed. Its notice is in `vendor/chess/chess-global.js`.
